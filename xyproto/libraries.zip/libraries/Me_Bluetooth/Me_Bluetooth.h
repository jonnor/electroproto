/******************************************************************************
* File Name          : Me_Bluetooth.h
* Author             : Steve
* Updated            : Jakob
* Version            : V1.0.1
* Date               : 2013-07-05
* Description        : Class for Makeblock Electronic modules of Me-Bluetooth.
                       The module can only be connected to the port 3, 4, 5, 6
                       of Me - Base Shield.
* License            : CC-BY-SA 3.0
* Copyright (C) 2011 Hulu Robot Technology Co., Ltd. All right reserved.
*******************************************************************************/

#ifndef Me_Bluetooth_h
#define Me_Bluetooth_h

#if defined(ARDUINO) && ARDUINO >= 100
  #include <Arduino.h>
#else
  #include <WProgram.h>
#endif

#include <Me_BaseShield.h>
#include <SoftwareSerial.h>
#include <WString.h>

#define BLUETOOTH_CONNECTED 1
#define BLUETOOTH_PAIRABLE 2


class Me_Bluetooth
{
public:
	Me_Bluetooth();
	//portNum can only be 3, 4, 5, 6
	Me_Bluetooth(int portNum);
	void begin(long baudrate);
	int setName(String name);
	size_t write(uint8_t byte);
	int read();
	int available();
	void flush();
	int checkConnected();
private:
	int port;
	long bdrate;
	SoftwareSerial swSerial;
	int bluetoothState;
};
#endif

